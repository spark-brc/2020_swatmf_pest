import os
from datetime import datetime
import pyemu
from sm_pst_par import riv_par
from sm_pst_utils import extract_day_str, extract_watertable_sim

wd = os.getcwd()
os.chdir(wd)
print(wd)

# -------------------- USER INPUTS ------------------------------------------- #
# Set dates
sim_start = '1/1/1995'
sim_end = '12/31/1995'
str_cali_start = '1/1/1995'
str_cali_end = '12/31/1995'
wt_cali_start = '1/1/1995'
wt_cali_end = '12/31/1995'

# file names
rch_file = 'output.rch'
# reach numbers that are used for calibration
subs = [58]
# Grid numbers that are used for calibration
grids = [5699, 5832]
# --------------------------------------------------------------------------- #

time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 30*'- ')
print(time + ' |  modify River parameters ... processing')
riv_par(wd)
print(time + ' |  modify River parameters ... passed')
print(30*'- ' + '\n')

time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 30*'- ')
print(time + ' |  modify SWAT parameters ... processing')
pyemu.os_utils.run('Swat_Edit.exe', cwd='.')
print(time + ' |  modify SWAT parameters ... passed')
print(30*'- ' + '\n')

time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 30*'- ')
print(time + ' |  run model ... processing')
# pyemu.os_utils.run('SWAT-MODFLOW3.exe >_s+m.stdout', cwd='.')
pyemu.os_utils.run('SWAT-MODFLOW3.exe', cwd='.')
time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print(time + ' |  run model ... passed')

time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 30*'- ')
print(time + ' |  extract simulated value ... processing')
extract_day_str(rch_file, subs, sim_start, str_cali_start, str_cali_end)
extract_watertable_sim(grids, wt_cali_start, wt_cali_end)
print(time + ' |  extract simulated value ... passed')
print(30*'- ' + '\n')



